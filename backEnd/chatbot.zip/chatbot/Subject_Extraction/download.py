import nltk 

nltk.download('maxent_ne_chunker') 
