﻿import json
import requests
from bs4 import BeautifulSoup

# Turing robot
def rnn_generator(message):
        return 'Building for future AI Chatbot.\n Thank you for your patience. '


if __name__ == '__main__':
    print (rnn_generator('AIChatbot'))
